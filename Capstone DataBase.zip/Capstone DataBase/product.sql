USE `scdb`;

INSERT INTO product (product_id, name, description, unit_price, quantity_available)
VALUES 
  (940985565, 'Alpha Widget', 'The Alpha Widget delivers exceptional performance and efficiency with advanced materials and innovative design.', '476.28', 1312413266),
  
  (2100107232, 'Beta Gadget', 'Beta Gadget offers cutting‐edge functionality and robust durability, setting new benchmarks in modern engineering.', '572.41', 1747775546),
  
  (728095261, 'Gamma Device', 'Gamma Device integrates state‐of‐the‐art technology with a sleek design, delivering reliable performance under demanding conditions.', '420.07', 1312841904),
  
  (1475282724, 'Delta Tool', 'Delta Tool is crafted for precision and versatility, providing outstanding performance for both industrial and consumer applications.', '853.06', 96217683),
  
  (258283553, 'Epsilon Instrument', 'Epsilon Instrument combines innovative design with superior functionality to ensure top‐tier efficiency and reliability.', '155.81', 1922105692),
  
  (112510080, 'Zeta Apparatus', 'Zeta Apparatus is engineered for precision and durability, making it ideal for high‐performance tasks in competitive markets.', '995.74', 1099950775),
  
  (1285289286, 'Eta Machine', 'Eta Machine delivers outstanding efficiency and innovative design tailored for modern industry demands.', '73.00', 652713284),
  
  (1852236165, 'Theta Engine', 'Theta Engine provides exceptional power and performance, optimized for a variety of professional applications.', '194.78', 807782821),
  
  (57772872, 'Iota Module', 'Iota Module offers a compact design and reliable performance, ideal for streamlining operational workflows.', '846.62', 8944384),
  
  (681593128, 'Kappa Unit', 'Kappa Unit features robust construction and state‐of‐the‐art technology, delivering consistent performance in every scenario.', '101.98', 1969859492),
  
  (579725689, 'Lambda Component', 'Lambda Component provides excellent functionality and an intuitive design, ensuring seamless integration into your systems.', '971.40', 687368460),
  
  (984509879, 'Mu Device', 'Mu Device stands out with its innovative engineering and reliable performance, designed to meet high industry standards.', '554.35', 1900148545),
  
  (1789289081, 'Nu Instrument', 'Nu Instrument is engineered for precision and efficiency, making it indispensable for modern professionals.', '139.54', 1361106350),
  
  (419209712, 'Xi Equipment', 'Xi Equipment delivers unparalleled reliability and advanced features that set the standard for performance.', '739.63', 1288902005),
  
  (1033150438, 'Omicron Gear', 'Omicron Gear combines innovative technology with rugged design, ensuring superior performance in demanding environments.', '822.99', 1654945798),
  
  (1980118493, 'Pi Accessory', 'Pi Accessory is designed with cutting‐edge technology and sleek aesthetics for optimal efficiency and style.', '325.96', 2005414748),
  
  (1627206589, 'Rho Component', 'Rho Component delivers unmatched precision and durability, engineered to exceed modern industry expectations.', '507.83', 809022376),
  
  (478295010, 'Sigma Part', 'Sigma Part offers reliable performance with a compact design, ensuring efficiency in everyday operations.', '82.98', 776323902),
  
  (442026775, 'Tau Element', 'Tau Element is crafted for durability and performance, featuring advanced design for consistent, reliable results.', '483.06', 505057223),
  
  (1783273305, 'Upsilon Device', 'Upsilon Device integrates advanced engineering with an intuitive design, making it a prime choice for modern applications.', '182.04', 1087914426),
  
  (474339815, 'Phi Module', 'Phi Module provides exceptional performance and efficiency, engineered for optimal functionality in dynamic environments.', '56.70', 494707408),
  
  (1778229465, 'Chi Instrument', 'Chi Instrument offers innovative features and reliable performance, designed to meet the challenges of a competitive market.', '915.26', 974478305),
  
  (598951432, 'Psi Apparatus', 'Psi Apparatus is engineered for high performance and versatility, setting new standards in operational efficiency.', '957.09', 1824884452),
  
  (568088518, 'Omega Tool', 'Omega Tool features cutting‐edge design and reliable performance, ensuring seamless integration into your workflow.', '85.21', 519423400),
  
  (2079380449, 'V22 Device', 'V22 Device offers sleek design and innovative technology, ensuring reliable performance in modern industrial settings.', '609.08', 321415542),
  
  (2076795595, 'W23 Tool', 'W23 Tool is designed for high efficiency and exceptional durability—a key asset for modern operations.', '135.43', 615559254),
  
  (987833627, 'X24 Accessory', 'X24 Accessory provides advanced functionality and sleek design, tailored for optimal performance in every task.', '253.66', 1785628259),
  
  (113942864, 'Y25 Component', 'Y25 Component delivers robust performance and innovative design, ensuring seamless integration in any workflow.', '811.77', 1152980596),
  
  (1767252653, 'Z26 Gadget', 'Z26 Gadget combines modern engineering with superior functionality, making it indispensable for contemporary challenges.', '799.66', 1532191867),
  
  (877426149, 'A27 Instrument', 'A27 Instrument offers exceptional performance with advanced technology, engineered for precision and reliability.', '265.34', 1091179556),
  
  (1085695081, 'B28 Device', 'B28 Device features a sleek, modern design and reliable performance, optimized for efficiency in any environment.', '487.29', 790501506),
  
  (1121806209, 'C29 Apparatus', 'C29 Apparatus is designed for consistent, high‐level performance with an emphasis on durability and innovation.', '60.45', 615851189),
  
  (107117209, 'D30 Module', 'D30 Module delivers top‐notch efficiency and cutting‐edge technology, perfect for streamlining operational workflows.', '155.03', 65812115),
  
  (1499099221, 'E31 Tool', 'E31 Tool offers superior engineering and innovative design, ensuring optimal performance and durability in every task.', '216.82', 2122938279),
  
  (2144039749, 'F32 Component', 'F32 Component combines state‐of‐the‐art technology with robust construction, setting new industry standards for performance.', '926.97', 810501469),
  
  (981587121, 'G33 Gadget', 'G33 Gadget features a sleek design and innovative functionality, making it a reliable solution for modern challenges.', '120.94', 790325504),
  
  (184527900, 'H34 Device', 'H34 Device offers exceptional performance and a modern design, engineered for efficiency and durability in demanding settings.', '697.69', 871375547),
  
  (148055131, 'I35 Instrument', 'I35 Instrument is designed for precision and reliability, featuring advanced technology to support dynamic operational needs.', '276.14', 25038508),
  
  (895491374, 'J36 Equipment', 'J36 Equipment delivers robust performance with a sleek design, ensuring consistent results and high efficiency.', '923.25', 1908999399),
  
  (1508782188, 'K37 Module', 'K37 Module combines cutting‐edge engineering with durable construction for superior, long‐lasting performance.', '843.60', 100659927),
  
  (1400143307, 'L38 Apparatus', 'L38 Apparatus offers advanced technology and exceptional performance, designed to optimize operational efficiency and reliability.', '588.40', 1760562919),
  
  (1343691291, 'M39 Component', 'M39 Component delivers innovative functionality and robust performance, engineered to exceed modern industry expectations.', '219.04', 158601183),
  
  (1407056335, 'N40 Accessory', 'N40 Accessory features a sleek design with advanced features for improved efficiency and operational excellence.', '593.02', 1731649861),
  
  (523775021, 'O41 Device', 'O41 Device integrates modern design with superior performance, ensuring reliability and efficiency in every application.', '359.05', 1785683857),
  
  (517213812, 'P42 Tool', 'P42 Tool offers innovative engineering and robust construction, delivering high performance for professional applications.', '277.23', 373653874),
  
  (1397092703, 'Q43 Instrument', 'Q43 Instrument delivers unmatched precision and durability, engineered to exceed modern industry expectations.', '833.85', 1440213635),
  
  (1828433276, 'R44 Module', 'R44 Module features advanced design and high performance, ensuring optimal results under challenging conditions.', '689.62', 382391880),
  
  (92879670, 'S45 Gadget', 'S45 Gadget offers a compact design with innovative features, making it an ideal solution for modern efficiency.', '94.59', 358678079),
  
  (400629681, 'T46 Equipment', 'T46 Equipment delivers robust performance and cutting‐edge technology, engineered to meet the demands of contemporary industry.', '468.93', 1583583611),
  
  (1244833108, 'U47 Apparatus', 'U47 Apparatus combines modern innovation with exceptional durability, setting new standards in operational excellence.', '334.66', 844449510),
  
  (1172015275, 'V48 Component', 'V48 Component is engineered for high performance and efficiency, offering innovative design features that drive productivity.', '798.78', 1322226967),
  
  (1572073439, 'W49 Instrument', 'W49 Instrument offers advanced functionality and robust performance, ensuring reliability and consistency in any environment.', '384.54', 453017185),
  
  (1411834737, 'X50 Device', 'X50 Device features cutting‐edge engineering and a sleek design, optimized for high performance and modern functionality.', '604.74', 1829201528),
  
  (736967162, 'Y51 Tool', 'Y51 Tool delivers reliable performance with a user‐friendly design, engineered to streamline operations and boost efficiency.', '816.87', 543817326),
  
  (1022993470, 'Z52 Module', 'Z52 Module integrates state‐of‐the‐art technology with robust construction, ensuring exceptional operational performance and durability.', '901.46', 2016889840),
  
  (876436523, 'Alpha2 Gadget', 'Alpha2 Gadget offers innovative design and exceptional efficiency, making it a reliable solution for modern enterprises.', '354.52', 157039410),
  
  (1878607227, 'Beta2 Instrument', 'Beta2 Instrument delivers superior performance and cutting‐edge technology, engineered for precision and consistency.', '262.78', 109391291),
  
  (414519847, 'Gamma2 Device', 'Gamma2 Device features a sleek, modern design with advanced functionality, ensuring optimal performance in any setting.', '107.16', 1452539975),
  
  (1793117561, 'Delta2 Apparatus', 'Delta2 Apparatus is engineered for high efficiency and robust performance, setting a new standard in industrial innovation.', '681.74', 1047356740),
  
  (1508782188, 'Epsilon2 Module', 'Epsilon2 Module offers advanced technology and sleek design, delivering reliable performance and exceptional durability.', '380.88', 2113945037),
  
  (1604345769, 'Zeta2 Component', 'Zeta2 Component is designed for efficiency and high performance, featuring state‐of‐the‐art engineering for modern applications.', '313.17', 410111705),
  
  (437157835, 'Eta2 Accessory', 'Eta2 Accessory combines innovative design with reliable functionality, ensuring seamless integration into any workflow.', '604.65', 1179467540),
  
  (471005300, 'Theta2 Tool', 'Theta2 Tool delivers outstanding performance and efficiency, engineered for high‐demand operations and professional use.', '424.75', 1274740924),
  
  (2076763301, 'Iota2 Device', 'Iota2 Device integrates modern design with superior performance, ensuring reliability and efficiency in every application.', '482.17', 991986639),
  
  (893573167, 'Kappa2 Instrument', 'Kappa2 Instrument offers state‐of‐the‐art functionality and innovative design, ensuring top‐tier performance in demanding environments.', '406.02', 2016177298),
  
  (2036681157, 'Lambda2 Module', 'Lambda2 Module combines advanced technology with robust construction, ensuring high efficiency and reliability.', '366.26', 1652652510),
  
  (2072488532, 'Mu2 Component', 'Mu2 Component delivers exceptional performance with a sleek design, making it indispensable for modern industry.', '690.47', 118818214),
  
  (1672789809, 'Nu2 Device', 'Nu2 Device offers cutting‐edge technology and innovative design, ensuring superior functionality and efficiency.', '368.40', 2090055520),
  
  (82064020, 'Xi2 Accessory', 'Xi2 Accessory features modern aesthetics and robust performance, designed to enhance productivity and operational efficiency.', '376.57', 1909159876),
  
  (334280806, 'Omicron Tool', 'Omicron Tool delivers exceptional performance and innovative features, engineered for high efficiency in demanding tasks.', '613.80', 370383848),
  
  (933304097, 'Pi2 Instrument', 'Pi2 Instrument offers advanced functionality and a compact design, ensuring optimal performance and ease of use.', '215.24', 1180269690),
  
  (1176553575, 'Rho2 Component', 'Rho2 Component is engineered for precision and durability, offering reliable performance and modern aesthetics for optimal results.', '19.95', 205207139),
  
  (194759979, 'Sigma2 Device', 'Sigma2 Device offers exceptional functionality and modern design, engineered for efficiency and durability in demanding settings.', '164.14', 2453412),
  
  (1199347202, 'Tau2 Gadget', 'Tau2 Gadget features innovative engineering and robust performance, designed to meet the demands of contemporary markets.', '196.99', 93921091),
  
  (1171111014, 'Upsilon2 Apparatus', 'Upsilon2 Apparatus delivers exceptional functionality and sleek design, engineered for high efficiency and reliability.', '765.48', 1693513734),
  
  (1572073439, 'W49 Instrument', 'W49 Instrument offers advanced functionality and robust performance, ensuring reliability and consistency in any environment.', '384.54', 453017185),
  
  (1411834737, 'X50 Device', 'X50 Device features cutting‐edge engineering and a sleek design, optimized for high performance and modern functionality.', '604.74', 1829201528),
  
  (736967162, 'Y51 Tool', 'Y51 Tool delivers reliable performance with a user‐friendly design, engineered to streamline operations and boost efficiency.', '816.87', 543817326),
  
  (1022993470, 'Z52 Module', 'Z52 Module integrates state‐of‐the‐art technology with robust construction, ensuring exceptional operational performance and durability.', '901.46', 2016889840),
  
  (876436523, 'Alpha2 Gadget', 'Alpha2 Gadget offers innovative design and exceptional efficiency, making it a reliable solution for modern enterprises.', '354.52', 157039410),
  
  (1878607227, 'Beta2 Instrument', 'Beta2 Instrument delivers superior performance and cutting‐edge technology, engineered for precision and consistency.', '262.78', 109391291),
  
  (414519847, 'Gamma2 Device', 'Gamma2 Device features a sleek, modern design with advanced functionality, ensuring optimal performance in any setting.', '107.16', 1452539975),
  
  (1793117561, 'Delta2 Apparatus', 'Delta2 Apparatus is engineered for high efficiency and robust performance, setting a new standard in industrial innovation.', '681.74', 1047356740),
  
  (1508782188, 'Epsilon2 Module', 'Epsilon2 Module offers advanced technology and sleek design, delivering reliable performance and exceptional durability.', '380.88', 2113945037),
  
  (1604345769, 'Zeta2 Component', 'Zeta2 Component is designed for efficiency and high performance, featuring state‐of‐the‐art engineering for modern applications.', '313.17', 410111705),
  
  (437157835, 'Eta2 Accessory', 'Eta2 Accessory combines innovative design with reliable functionality, ensuring seamless integration into any workflow.', '604.65', 1179467540),
  
  (471005300, 'Theta2 Tool', 'Theta2 Tool delivers outstanding performance and efficiency, engineered for high‐demand operations and professional use.', '424.75', 1274740924),
  
  (2076763301, 'Iota2 Device', 'Iota2 Device integrates modern design with superior performance, ensuring reliability and efficiency in every application.', '482.17', 991986639),
  
  (893573167, 'Kappa2 Instrument', 'Kappa2 Instrument offers state‐of‐the‐art functionality and innovative design, ensuring top‐tier performance in demanding environments.', '406.02', 2016177298),
  
  (2036681157, 'Lambda2 Module', 'Lambda2 Module combines advanced technology with robust construction, ensuring high efficiency and reliability.', '366.26', 1652652510),
  
  (2072488532, 'Mu2 Component', 'Mu2 Component delivers exceptional performance with a sleek design, making it indispensable for modern industry.', '690.47', 118818214),
  
  (1672789809, 'Nu2 Device', 'Nu2 Device offers cutting‐edge technology and innovative design, ensuring superior functionality and efficiency.', '368.40', 2090055520),
  
  (82064020, 'Xi2 Accessory', 'Xi2 Accessory features modern aesthetics and robust performance, designed to enhance productivity and operational efficiency.', '376.57', 1909159876),
  
  (334280806, 'Omicron Tool', 'Omicron Tool delivers exceptional performance and innovative features, engineered for high efficiency in demanding tasks.', '613.80', 370383848),
  
  (933304097, 'Pi2 Instrument', 'Pi2 Instrument offers advanced functionality and a compact design, ensuring optimal performance and ease of use.', '215.24', 1180269690),
  
  (1176553575, 'Rho2 Component', 'Rho2 Component is engineered for precision and durability, offering reliable performance and modern aesthetics for optimal results.', '19.95', 205207139),
  
  (194759979, 'Sigma2 Device', 'Sigma2 Device offers exceptional functionality and modern design, engineered for efficiency and durability in demanding settings.', '164.14', 2453412),
  
  (1199347202, 'Tau2 Gadget', 'Tau2 Gadget features innovative engineering and robust performance, designed to meet the demands of contemporary markets.', '196.99', 93921091),
  
  (1171111014, 'Upsilon2 Apparatus', 'Upsilon2 Apparatus delivers exceptional functionality and sleek design, engineered for high efficiency and reliability.', '765.48', 1693513734),
  
  (1572073439, 'W49 Instrument', 'W49 Instrument offers advanced functionality and robust performance, ensuring reliability and consistency in any environment.', '384.54', 453017185),
  
  (1411834737, 'X50 Device', 'X50 Device features cutting‐edge engineering and a sleek design, optimized for high performance and modern functionality.', '604.74', 1829201528),
  
  (736967162, 'Y51 Tool', 'Y51 Tool delivers reliable performance with a user‐friendly design, engineered to streamline operations and boost efficiency.', '816.87', 543817326),
  
  (1022993470, 'Z52 Module', 'Z52 Module integrates state‐of‐the‐art technology with robust construction, ensuring exceptional operational performance and durability.', '901.46', 2016889840),
  
  (876436523, 'Alpha2 Gadget', 'Alpha2 Gadget offers innovative design and exceptional efficiency, making it a reliable solution for modern enterprises.', '354.52', 157039410),
  
  (1878607227, 'Beta2 Instrument', 'Beta2 Instrument delivers superior performance and cutting‐edge technology, engineered for precision and consistency.', '262.78', 109391291),
  
  (414519847, 'Gamma2 Device', 'Gamma2 Device features a sleek, modern design with advanced functionality, ensuring optimal performance in any setting.', '107.16', 1452539975),
  
  (1793117561, 'Delta2 Apparatus', 'Delta2 Apparatus is engineered for high efficiency and robust performance, setting a new standard in industrial innovation.', '681.74', 1047356740),
  
  (1508782188, 'Epsilon2 Module', 'Epsilon2 Module offers advanced technology and sleek design, delivering reliable performance and exceptional durability.', '380.88', 2113945037),
  
  (1604345769, 'Zeta2 Component', 'Zeta2 Component is designed for efficiency and high performance, featuring state‐of‐the‐art engineering for modern applications.', '313.17', 410111705),
  
  (437157835, 'Eta2 Accessory', 'Eta2 Accessory combines innovative design with reliable functionality, ensuring seamless integration into any workflow.', '604.65', 1179467540),
  
  (471005300, 'Theta2 Tool', 'Theta2 Tool delivers outstanding performance and efficiency, engineered for high‐demand operations and professional use.', '424.75', 1274740924),
  
  (2076763301, 'Iota2 Device', 'Iota2 Device integrates modern design with superior performance, ensuring reliability and efficiency in every application.', '482.17', 991986639),
  
  (893573167, 'Kappa2 Instrument', 'Kappa2 Instrument offers state‐of‐the‐art functionality and innovative design, ensuring top‐tier performance in demanding environments.', '406.02', 2016177298),
  
  (2036681157, 'Lambda2 Module', 'Lambda2 Module combines advanced technology with robust construction, ensuring high efficiency and reliability.', '366.26', 1652652510),
  
  (2072488532, 'Mu2 Component', 'Mu2 Component delivers exceptional performance with a sleek design, making it indispensable for modern industry.', '690.47', 118818214),
  
  (1672789809, 'Nu2 Device', 'Nu2 Device offers cutting‐edge technology and innovative design, ensuring superior functionality and efficiency.', '368.40', 2090055520),
  
  (82064020, 'Xi2 Accessory', 'Xi2 Accessory features modern aesthetics and robust performance, designed to enhance productivity and operational efficiency.', '376.57', 1909159876),
  
  (334280806, 'Omicron Tool', 'Omicron Tool delivers exceptional performance and innovative features, engineered for high efficiency in demanding tasks.', '613.80', 370383848),
  
  (933304097, 'Pi2 Instrument', 'Pi2 Instrument offers advanced functionality and a compact design, ensuring optimal performance and ease of use.', '215.24', 1180269690),
  
  (1176553575, 'Rho2 Component', 'Rho2 Component is engineered for precision and durability, offering reliable performance and modern aesthetics for optimal results.', '19.95', 205207139),
  
  (194759979, 'Sigma2 Device', 'Sigma2 Device offers exceptional functionality and modern design, engineered for efficiency and durability in demanding settings.', '164.14', 2453412),
  
  (1199347202, 'Tau2 Gadget', 'Tau2 Gadget features innovative engineering and robust performance, designed to meet the demands of contemporary markets.', '196.99', 93921091),
  
  (1171111014, 'Upsilon2 Apparatus', 'Upsilon2 Apparatus delivers exceptional functionality and sleek design, engineered for high efficiency and reliability.', '765.48', 1693513734),
  
  (1572073439, 'W49 Instrument', 'W49 Instrument offers advanced functionality and robust performance, ensuring reliability and consistency in any environment.', '384.54', 453017185),
  
  (1411834737, 'X50 Device', 'X50 Device features cutting‐edge engineering and a sleek design, optimized for high performance and modern functionality.', '604.74', 1829201528),
  
  (736967162, 'Y51 Tool', 'Y51 Tool delivers reliable performance with a user‐friendly design, engineered to streamline operations and boost efficiency.', '816.87', 543817326),
  
  (1022993470, 'Z52 Module', 'Z52 Module integrates state‐of‐the‐art technology with robust construction, ensuring exceptional operational performance and durability.', '901.46', 2016889840),
  
  (876436523, 'Alpha2 Gadget', 'Alpha2 Gadget offers innovative design and exceptional efficiency, making it a reliable solution for modern enterprises.', '354.52', 157039410),
  
  (1878607227, 'Beta2 Instrument', 'Beta2 Instrument delivers superior performance and cutting‐edge technology, engineered for precision and consistency.', '262.78', 109391291),
  
  (414519847, 'Gamma2 Device', 'Gamma2 Device features a sleek, modern design with advanced functionality, ensuring optimal performance in any setting.', '107.16', 1452539975),
  
  (1793117561, 'Delta2 Apparatus', 'Delta2 Apparatus is engineered for high efficiency and robust performance, setting a new standard in industrial innovation.', '681.74', 1047356740),
  
  (1508782188, 'Epsilon2 Module', 'Epsilon2 Module offers advanced technology and sleek design, delivering reliable performance and exceptional durability.', '380.88', 2113945037),
  
  (1604345769, 'Zeta2 Component', 'Zeta2 Component is designed for efficiency and high performance, featuring state‐of‐the‐art engineering for modern applications.', '313.17', 410111705),
  
  (437157835, 'Eta2 Accessory', 'Eta2 Accessory combines innovative design with reliable functionality, ensuring seamless integration into any workflow.', '604.65', 1179467540),
  
  (471005300, 'Theta2 Tool', 'Theta2 Tool delivers outstanding performance and efficiency, engineered for high‐demand operations and professional use.', '424.75', 1274740924),
  
  (2076763301, 'Iota2 Device', 'Iota2 Device integrates modern design with superior performance, ensuring reliability and efficiency in every application.', '482.17', 991986639),
  
  (893573167, 'Kappa2 Instrument', 'Kappa2 Instrument offers state‐of‐the‐art functionality and innovative design, ensuring top‐tier performance in demanding environments.', '406.02', 2016177298),
  
  (2036681157, 'Lambda2 Module', 'Lambda2 Module combines advanced technology with robust construction, ensuring high efficiency and reliability.', '366.26', 1652652510),
  
  (2072488532, 'Mu2 Component', 'Mu2 Component delivers exceptional performance with a sleek design, making it indispensable for modern industry.', '690.47', 118818214),
  
  (1672789809, 'Nu2 Device', 'Nu2 Device offers cutting‐edge technology and innovative design, ensuring superior functionality and efficiency.', '368.40', 2090055520),
  
  (82064020, 'Xi2 Accessory', 'Xi2 Accessory features modern aesthetics and robust performance, designed to enhance productivity and operational efficiency.', '376.57', 1909159876),
  
  (334280806, 'Omicron Tool', 'Omicron Tool delivers exceptional performance and innovative features, engineered for high efficiency in demanding tasks.', '613.80', 370383848),
  
  (933304097, 'Pi2 Instrument', 'Pi2 Instrument offers advanced functionality and a compact design, ensuring optimal performance and ease of use.', '215.24', 1180269690),
  
  (1176553575, 'Rho2 Component', 'Rho2 Component is engineered for precision and durability, offering reliable performance and modern aesthetics for optimal results.', '19.95', 205207139),
  
  (194759979, 'Sigma2 Device', 'Sigma2 Device offers exceptional functionality and modern design, engineered for efficiency and durability in demanding settings.', '164.14', 2453412),
  
  (1199347202, 'Tau2 Gadget', 'Tau2 Gadget features innovative engineering and robust performance, designed to meet the demands of contemporary markets.', '196.99', 93921091),
  
  (1171111014, 'Upsilon2 Apparatus', 'Upsilon2 Apparatus delivers exceptional functionality and sleek design, engineered for high efficiency and reliability.', '765.48', 1693513734),
  
  (1572073439, 'W49 Instrument', 'W49 Instrument offers advanced functionality and robust performance, ensuring reliability and consistency in any environment.', '384.54', 453017185),
  
  (1411834737, 'X50 Device', 'X50 Device features cutting‐edge engineering and a sleek design, optimized for high performance and modern functionality.', '604.74', 1829201528),
  
  (736967162, 'Y51 Tool', 'Y51 Tool delivers reliable performance with a user‐friendly design, engineered to streamline operations and boost efficiency.', '816.87', 543817326),
  
  (1022993470, 'Z52 Module', 'Z52 Module integrates state‐of‐the‐art technology with robust construction, ensuring exceptional operational performance and durability.', '901.46', 2016889840),
  
  (876436523, 'Alpha2 Gadget', 'Alpha2 Gadget offers innovative design and exceptional efficiency, making it a reliable solution for modern enterprises.', '354.52', 157039410),
  
  (1878607227, 'Beta2 Instrument', 'Beta2 Instrument delivers superior performance and cutting‐edge technology, engineered for precision and consistency.', '262.78', 109391291),
  
  (414519847, 'Gamma2 Device', 'Gamma2 Device features a sleek, modern design with advanced functionality, ensuring optimal performance in any setting.', '107.16', 1452539975),
  
  (1793117561, 'Delta2 Apparatus', 'Delta2 Apparatus is engineered for high efficiency and robust performance, setting a new standard in industrial innovation.', '681.74', 1047356740),
  
  (1508782188, 'Epsilon2 Module', 'Epsilon2 Module offers advanced technology and sleek design, delivering reliable performance and exceptional durability.', '380.88', 2113945037),
  
  (1604345769, 'Zeta2 Component', 'Zeta2 Component is designed for efficiency and high performance, featuring state‐of‐the‐art engineering for modern applications.', '313.17', 410111705),
  
  (437157835, 'Eta2 Accessory', 'Eta2 Accessory combines innovative design with reliable functionality, ensuring seamless integration into any workflow.', '604.65', 1179467540),
  
  (471005300, 'Theta2 Tool', 'Theta2 Tool delivers outstanding performance and efficiency, engineered for high‐demand operations and professional use.', '424.75', 1274740924),
  
  (2076763301, 'Iota2 Device', 'Iota2 Device integrates modern design with superior performance, ensuring reliability and efficiency in every application.', '482.17', 991986639),
  
  (893573167, 'Kappa2 Instrument', 'Kappa2 Instrument offers state‐of‐the‐art functionality and innovative design, ensuring top‐tier performance in demanding environments.', '406.02', 2016177298),
  
  (2036681157, 'Lambda2 Module', 'Lambda2 Module combines advanced technology with robust construction, ensuring high efficiency and reliability.', '366.26', 1652652510),
  
  (2072488532, 'Mu2 Component', 'Mu2 Component delivers exceptional performance with a sleek design, making it indispensable for modern industry.', '690.47', 118818214),
  
  (1672789809, 'Nu2 Device', 'Nu2 Device offers cutting‐edge technology and innovative design, ensuring superior functionality and efficiency.', '368.40', 2090055520),
  
  (82064020, 'Xi2 Accessory', 'Xi2 Accessory features modern aesthetics and robust performance, designed to enhance productivity and operational efficiency.', '376.57', 1909159876),
  
  (334280806, 'Omicron Tool', 'Omicron Tool delivers exceptional performance and innovative features, engineered for high efficiency in demanding tasks.', '613.80', 370383848),
  
  (933304097, 'Pi2 Instrument', 'Pi2 Instrument offers advanced functionality and a compact design, ensuring optimal performance and ease of use.', '215.24', 1180269690),
  
  (1176553575, 'Rho2 Component', 'Rho2 Component is engineered for precision and durability, offering reliable performance and modern aesthetics for optimal results.', '19.95', 205207139),
  
  (194759979, 'Sigma2 Device', 'Sigma2 Device offers exceptional functionality and modern design, engineered for efficiency and durability in demanding settings.', '164.14', 2453412),
  
  (1199347202, 'Tau2 Gadget', 'Tau2 Gadget features innovative engineering and robust performance, designed to meet the demands of contemporary markets.', '196.99', 93921091),
  
  (1171111014, 'Upsilon2 Apparatus', 'Upsilon2 Apparatus delivers exceptional functionality and sleek design, engineered for high efficiency and reliability.', '765.48', 1693513734),
  
  (1572073439, 'W49 Instrument', 'W49 Instrument offers advanced functionality and robust performance, ensuring reliability and consistency in any environment.', '384.54', 453017185),
  
  (1411834737, 'X50 Device', 'X50 Device features cutting‐edge engineering and a sleek design, optimized for high performance and modern functionality.', '604.74', 1829201528),
  
  (736967162, 'Y51 Tool', 'Y51 Tool delivers reliable performance with a user‐friendly design, engineered to streamline operations and boost efficiency.', '816.87', 543817326),
  
  (1022993470, 'Z52 Module', 'Z52 Module integrates state‐of‐the‐art technology with robust construction, ensuring exceptional operational performance and durability.', '901.46', 2016889840),
  
  (876436523, 'Alpha2 Gadget', 'Alpha2 Gadget offers innovative design and exceptional efficiency, making it a reliable solution for modern enterprises.', '354.52', 157039410),
  
  (1878607227, 'Beta2 Instrument', 'Beta2 Instrument delivers superior performance and cutting‐edge technology, engineered for precision and consistency.', '262.78', 109391291),
  
  (414519847, 'Gamma2 Device', 'Gamma2 Device features a sleek, modern design with advanced functionality, ensuring optimal performance in any setting.', '107.16', 1452539975),
  
  (1793117561, 'Delta2 Apparatus', 'Delta2 Apparatus is engineered for high efficiency and robust performance, setting a new standard in industrial innovation.', '681.74', 1047356740),
  
  (1508782188, 'Epsilon2 Module', 'Epsilon2 Module offers advanced technology and sleek design, delivering reliable performance and exceptional durability.', '380.88', 2113945037),
  
  (1604345769, 'Zeta2 Component', 'Zeta2 Component is designed for efficiency and high performance, featuring state‐of‐the‐art engineering for modern applications.', '313.17', 410111705),
  
  (437157835, 'Eta2 Accessory', 'Eta2 Accessory combines innovative design with reliable functionality, ensuring seamless integration into any workflow.', '604.65', 1179467540),
  
  (471005300, 'Theta2 Tool', 'Theta2 Tool delivers outstanding performance and efficiency, engineered for high‐demand operations and professional use.', '424.75', 1274740924),
  
  (2076763301, 'Iota2 Device', 'Iota2 Device integrates modern design with superior performance, ensuring reliability and efficiency in every application.', '482.17', 991986639),
  
  (893573167, 'Kappa2 Instrument', 'Kappa2 Instrument offers state‐of‐the‐art functionality and innovative design, ensuring top‐tier performance in demanding environments.', '406.02', 2016177298),
  
  (2036681157, 'Lambda2 Module', 'Lambda2 Module combines advanced technology with robust construction, ensuring high efficiency and reliability.', '366.26', 1652652510),
  
  (2072488532, 'Mu2 Component', 'Mu2 Component delivers exceptional performance with a sleek design, making it indispensable for modern industry.', '690.47', 118818214),
  
  (1672789809, 'Nu2 Device', 'Nu2 Device offers cutting‐edge technology and innovative design, ensuring superior functionality and efficiency.', '368.40', 2090055520),
  
  (82064020, 'Xi2 Accessory', 'Xi2 Accessory features modern aesthetics and robust performance, designed to enhance productivity and operational efficiency.', '376.57', 1909159876),
  
  (334280806, 'Omicron Tool', 'Omicron Tool delivers exceptional performance and innovative features, engineered for high efficiency in demanding tasks.', '613.80', 370383848),
  
  (933304097, 'Pi2 Instrument', 'Pi2 Instrument offers advanced functionality and a compact design, ensuring optimal performance and ease of use.', '215.24', 1180269690),
  
  (1176553575, 'Rho2 Component', 'Rho2 Component is engineered for precision and durability, offering reliable performance and modern aesthetics for optimal results.', '19.95', 205207139),
  
  (194759979, 'Sigma2 Device', 'Sigma2 Device offers exceptional functionality and modern design, engineered for efficiency and durability in demanding settings.', '164.14', 2453412),
  
  (1199347202, 'Tau2 Gadget', 'Tau2 Gadget features innovative engineering and robust performance, designed to meet the demands of contemporary markets.', '196.99', 93921091),
  
  (1171111014, 'Upsilon2 Apparatus', 'Upsilon2 Apparatus delivers exceptional functionality and sleek design, engineered for high efficiency and reliability.', '765.48', 1693513734),
  
  (1572073439, 'W49 Instrument', 'W49 Instrument offers advanced functionality and robust performance, ensuring reliability and consistency in any environment.', '384.54', 453017185),
  
  (1411834737, 'X50 Device', 'X50 Device features cutting‐edge engineering and a sleek design, optimized for high performance and modern functionality.', '604.74', 1829201528),
  
  (736967162, 'Y51 Tool', 'Y51 Tool delivers reliable performance with a user‐friendly design, engineered to streamline operations and boost efficiency.', '816.87', 543817326),
  
  (1022993470, 'Z52 Module', 'Z52 Module integrates state‐of‐the‐art technology with robust construction, ensuring exceptional operational performance and durability.', '901.46', 2016889840),
  
  (876436523, 'Alpha2 Gadget', 'Alpha2 Gadget offers innovative design and exceptional efficiency, making it a reliable solution for modern enterprises.', '354.52', 157039410),
  
  (1878607227, 'Beta2 Instrument', 'Beta2 Instrument delivers superior performance and cutting‐edge technology, engineered for precision and consistency.', '262.78', 109391291),
  
  (414519847, 'Gamma2 Device', 'Gamma2 Device features a sleek, modern design with advanced functionality, ensuring optimal performance in any setting.', '107.16', 1452539975),
  
  (1793117561, 'Delta2 Apparatus', 'Delta2 Apparatus is engineered for high efficiency and robust performance, setting a new standard in industrial innovation.', '681.74', 1047356740),
  
  (1508782188, 'Epsilon2 Module', 'Epsilon2 Module offers advanced technology and sleek design, delivering reliable performance and exceptional durability.', '380.88', 2113945037),
  
  (1604345769, 'Zeta2 Component', 'Zeta2 Component is designed for efficiency and high performance, featuring state‐of‐the‐art engineering for modern applications.', '313.17', 410111705),
  
  (437157835, 'Eta2 Accessory', 'Eta2 Accessory combines innovative design with reliable functionality, ensuring seamless integration into any workflow.', '604.65', 1179467540),
  
  (471005300, 'Theta2 Tool', 'Theta2 Tool delivers outstanding performance and efficiency, engineered for high‐demand operations and professional use.', '424.75', 1274740924),
  
  (2076763301, 'Iota2 Device', 'Iota2 Device integrates modern design with superior performance, ensuring reliability and efficiency in every application.', '482.17', 991986639),
  
  (893573167, 'Kappa2 Instrument', 'Kappa2 Instrument offers state‐of‐the‐art functionality and innovative design, ensuring top‐tier performance in demanding environments.', '406.02', 2016177298),
  
  (2036681157, 'Lambda2 Module', 'Lambda2 Module combines advanced technology with robust construction, ensuring high efficiency and reliability.', '366.26', 1652652510),
  
  (2072488532, 'Mu2 Component', 'Mu2 Component delivers exceptional performance with a sleek design, making it indispensable for modern industry.', '690.47', 118818214),
  
  (1672789809, 'Nu2 Device', 'Nu2 Device offers cutting‐edge technology and innovative design, ensuring superior functionality and efficiency.', '368.40', 2090055520),
  
  (82064020, 'Xi2 Accessory', 'Xi2 Accessory features modern aesthetics and robust performance, designed to enhance productivity and operational efficiency.', '376.57', 1909159876),
  
  (334280806, 'Omicron Tool', 'Omicron Tool delivers exceptional performance and innovative features, engineered for high efficiency in demanding tasks.', '613.80', 370383848),
  
  (933304097, 'Pi2 Instrument', 'Pi2 Instrument offers advanced functionality and a compact design, ensuring optimal performance and ease of use.', '215.24', 1180269690),
  
  (1176553575, 'Rho2 Component', 'Rho2 Component is engineered for precision and durability, offering reliable performance and modern aesthetics for optimal results.', '19.95', 205207139),
  
  (194759979, 'Sigma2 Device', 'Sigma2 Device offers exceptional functionality and modern design, engineered for efficiency and durability in demanding settings.', '164.14', 2453412),
  
  (1199347202, 'Tau2 Gadget', 'Tau2 Gadget features innovative engineering and robust performance, designed to meet the demands of contemporary markets.', '196.99', 93921091),
  
  (1171111014, 'Upsilon2 Apparatus', 'Upsilon2 Apparatus delivers exceptional functionality and sleek design, engineered for high efficiency and reliability.', '765.48', 1693513734),
  
  (1572073439, 'W49 Instrument', 'W49 Instrument offers advanced functionality and robust performance, ensuring reliability and consistency in any environment.', '384.54', 453017185),
  
  (1411834737, 'X50 Device', 'X50 Device features cutting‐edge engineering and a sleek design, optimized for high performance and modern functionality.', '604.74', 1829201528),
  
  (736967162, 'Y51 Tool', 'Y51 Tool delivers reliable performance with a user‐friendly design, engineered to streamline operations and boost efficiency.', '816.87', 543817326),
  
  (1022993470, 'Z52 Module', 'Z52 Module integrates state‐of‐the‐art technology with robust construction, ensuring exceptional operational performance and durability.', '901.46', 2016889840),
  
  (876436523, 'Alpha2 Gadget', 'Alpha2 Gadget offers innovative design and exceptional efficiency, making it a reliable solution for modern enterprises.', '354.52', 157039410),
  
  (1878607227, 'Beta2 Instrument', 'Beta2 Instrument delivers superior performance and cutting‐edge technology, engineered for precision and consistency.', '262.78', 109391291),
  
  (414519847, 'Gamma2 Device', 'Gamma2 Device features a sleek, modern design with advanced functionality, ensuring optimal performance in any setting.', '107.16', 1452539975),
  
  (1793117561, 'Delta2 Apparatus', 'Delta2 Apparatus is engineered for high efficiency and robust performance, setting a new standard in industrial innovation.', '681.74', 1047356740),
  
  (1508782188, 'Epsilon2 Module', 'Epsilon2 Module offers advanced technology and sleek design, delivering reliable performance and exceptional durability.', '380.88', 2113945037),
  
  (1604345769, 'Zeta2 Component', 'Zeta2 Component is designed for efficiency and high performance, featuring state‐of‐the‐art engineering for modern applications.', '313.17', 410111705),
  
  (437157835, 'Eta2 Accessory', 'Eta2 Accessory combines innovative design with reliable functionality, ensuring seamless integration into any workflow.', '604.65', 1179467540),
  
  (471005300, 'Theta2 Tool', 'Theta2 Tool delivers outstanding performance and efficiency, engineered for high‐demand operations and professional use.', '424.75', 1274740924),
  
  (2076763301, 'Iota2 Device', 'Iota2 Device integrates modern design with superior performance, ensuring reliability and efficiency in every application.', '482.17', 991986639),
  
  (893573167, 'Kappa2 Instrument', 'Kappa2 Instrument offers state‐of‐the‐art functionality and innovative design, ensuring top‐tier performance in demanding environments.', '406.02', 2016177298),
  
  (2036681157, 'Lambda2 Module', 'Lambda2 Module combines advanced technology with robust construction, ensuring high efficiency and reliability.', '366.26', 1652652510),
  
  (2072488532, 'Mu2 Component', 'Mu2 Component delivers exceptional performance with a sleek design, making it indispensable for modern industry.', '690.47', 118818214),
  
  (1672789809, 'Nu2 Device', 'Nu2 Device offers cutting‐edge technology and innovative design, ensuring superior functionality and efficiency.', '368.40', 2090055520),
  
  (82064020, 'Xi2 Accessory', 'Xi2 Accessory features modern aesthetics and robust performance, designed to enhance productivity and operational efficiency.', '376.57', 1909159876),
  
  (334280806, 'Omicron Tool', 'Omicron Tool delivers exceptional performance and innovative features, engineered for high efficiency in demanding tasks.', '613.80', 370383848),
  
  (933304097, 'Pi2 Instrument', 'Pi2 Instrument offers advanced functionality and a compact design, ensuring optimal performance and ease of use.', '215.24', 1180269690),
  
  (1176553575, 'Rho2 Component', 'Rho2 Component is engineered for precision and durability, offering reliable performance and modern aesthetics for optimal results.', '19.95', 205207139),
  
  (194759979, 'Sigma2 Device', 'Sigma2 Device offers exceptional functionality and modern design, engineered for efficiency and durability in demanding settings.', '164.14', 2453412),
  
  (1199347202, 'Tau2 Gadget', 'Tau2 Gadget features innovative engineering and robust performance, designed to meet the demands of contemporary markets.', '196.99', 93921091),
  
  (1171111014, 'Upsilon2 Apparatus', 'Upsilon2 Apparatus delivers exceptional functionality and sleek design, engineered for high efficiency and reliability.', '765.48', 1693513734),
  
  (1572073439, 'W49 Instrument', 'W49 Instrument offers advanced functionality and robust performance, ensuring reliability and consistency in any environment.', '384.54', 453017185),
  
  (1411834737, 'X50 Device', 'X50 Device features cutting‐edge engineering and a sleek design, optimized for high performance and modern functionality.', '604.74', 1829201528),
  
  (736967162, 'Y51 Tool', 'Y51 Tool delivers reliable performance with a user‐friendly design, engineered to streamline operations and boost efficiency.', '816.87', 543817326),
  
  (1022993470, 'Z52 Module', 'Z52 Module integrates state‐of‐the‐art technology with robust construction, ensuring exceptional operational performance and durability.', '901.46', 2016889840),
  
  (876436523, 'Alpha2 Gadget', 'Alpha2 Gadget offers innovative design and exceptional efficiency, making it a reliable solution for modern enterprises.', '354.52', 157039410),
  
  (1878607227, 'Beta2 Instrument', 'Beta2 Instrument delivers superior performance and cutting‐edge technology, engineered for precision and consistency.', '262.78', 109391291),
  
  (414519847, 'Gamma2 Device', 'Gamma2 Device features a sleek, modern design with advanced functionality, ensuring optimal performance in any setting.', '107.16', 1452539975),
  
  (1793117561, 'Delta2 Apparatus', 'Delta2 Apparatus is engineered for high efficiency and robust performance, setting a new standard in industrial innovation.', '681.74', 1047356740),
  
  (1508782188, 'Epsilon2 Module', 'Epsilon2 Module offers advanced technology and sleek design, delivering reliable performance and exceptional durability.', '380.88', 2113945037),
  
  (1604345769, 'Zeta2 Component', 'Zeta2 Component is designed for efficiency and high performance, featuring state‐of‐the‐art engineering for modern applications.', '313.17', 410111705),
  
  (437157835, 'Eta2 Accessory', 'Eta2 Accessory combines innovative design with reliable functionality, ensuring seamless integration into any workflow.', '604.65', 1179467540),
  
  (471005300, 'Theta2 Tool', 'Theta2 Tool delivers outstanding performance and efficiency, engineered for high‐demand operations and professional use.', '424.75', 1274740924),
  
  (2076763301, 'Iota2 Device', 'Iota2 Device integrates modern design with superior performance, ensuring reliability and efficiency in every application.', '482.17', 991986639),
  
  (893573167, 'Kappa2 Instrument', 'Kappa2 Instrument offers state‐of‐the‐art functionality and innovative design, ensuring top‐tier performance in demanding environments.', '406.02', 2016177298),
  
  (2036681157, 'Lambda2 Module', 'Lambda2 Module combines advanced technology with robust construction, ensuring high efficiency and reliability.', '366.26', 1652652510),
  
  (2072488532, 'Mu2 Component', 'Mu2 Component delivers exceptional performance with a sleek design, making it indispensable for modern industry.', '690.47', 118818214),
  
  (1672789809, 'Nu2 Device', 'Nu2 Device offers cutting‐edge technology and innovative design, ensuring superior functionality and efficiency.', '368.40', 2090055520),
  
  (82064020, 'Xi2 Accessory', 'Xi2 Accessory features modern aesthetics and robust performance, designed to enhance productivity and operational efficiency.', '376.57', 1909159876),
  
  (334280806, 'Omicron Tool', 'Omicron Tool delivers exceptional performance and innovative features, engineered for high efficiency in demanding tasks.', '613.80', 370383848),
  
  (933304097, 'Pi2 Instrument', 'Pi2 Instrument offers advanced functionality and a compact design, ensuring optimal performance and ease of use.', '215.24', 1180269690),
  
  (1176553575, 'Rho2 Component', 'Rho2 Component is engineered for precision and durability, offering reliable performance and modern aesthetics for optimal results.', '19.95', 205207139),
  
  (194759979, 'Sigma2 Device', 'Sigma2 Device offers exceptional functionality and modern design, engineered for efficiency and durability in demanding settings.', '164.14', 2453412),
  
  (1199347202, 'Tau2 Gadget', 'Tau2 Gadget features innovative engineering and robust performance, designed to meet the demands of contemporary markets.', '196.99', 93921091),
  
  (1171111014, 'Upsilon2 Apparatus', 'Upsilon2 Apparatus delivers exceptional functionality and sleek design, engineered for high efficiency and reliability.', '765.48', 1693513734),
  
  (1572073439, 'W49 Instrument', 'W49 Instrument offers advanced functionality and robust performance, ensuring reliability and consistency in any environment.', '384.54', 453017185),
  
  (1411834737, 'X50 Device', 'X50 Device features cutting‐edge engineering and a sleek design, optimized for high performance and modern functionality.', '604.74', 1829201528),
  
  (736967162, 'Y51 Tool', 'Y51 Tool delivers reliable performance with a user‐friendly design, engineered to streamline operations and boost efficiency.', '816.87', 543817326),
  
  (1022993470, 'Z52 Module', 'Z52 Module integrates state‐of‐the‐art technology with robust construction, ensuring exceptional operational performance and durability.', '901.46', 2016889840),
  
  (876436523, 'Alpha2 Gadget', 'Alpha2 Gadget offers innovative design and exceptional efficiency, making it a reliable solution for modern enterprises.', '354.52', 157039410),
  
  (1878607227, 'Beta2 Instrument', 'Beta2 Instrument delivers superior performance and cutting‐edge technology, engineered for precision and consistency.', '262.78', 109391291),
  
  (414519847, 'Gamma2 Device', 'Gamma2 Device features a sleek, modern design with advanced functionality, ensuring optimal performance in any setting.', '107.16', 1452539975),
  
  (1793117561, 'Delta2 Apparatus', 'Delta2 Apparatus is engineered for high efficiency and robust performance, setting a new standard in industrial innovation.', '681.74', 1047356740),
  
  (1508782188, 'Epsilon2 Module', 'Epsilon2 Module offers advanced technology and sleek design, delivering reliable performance and exceptional durability.', '380.88', 2113945037),
  
  (1604345769, 'Zeta2 Component', 'Zeta2 Component is designed for efficiency and high performance, featuring state‐of‐the‐art engineering for modern applications.', '313.17', 410111705),
  
  (437157835, 'Eta2 Accessory', 'Eta2 Accessory combines innovative design with reliable functionality, ensuring seamless integration into any workflow.', '604.65', 1179467540),
  
  (471005300, 'Theta2 Tool', 'Theta2 Tool delivers outstanding performance and efficiency, engineered for high‐demand operations and professional use.', '424.75', 1274740924),
  
  (2076763301, 'Iota2 Device', 'Iota2 Device integrates modern design with superior performance, ensuring reliability and efficiency in every application.', '482.17', 991986639),
  
  (893573167, 'Kappa2 Instrument', 'Kappa2 Instrument offers state‐of‐the‐art functionality and innovative design, ensuring top‐tier performance in demanding environments.', '406.02', 2016177298),
  
  (2036681157, 'Lambda2 Module', 'Lambda2 Module combines advanced technology with robust construction, ensuring high efficiency and reliability.', '366.26', 1652652510),
  
  (2072488532, 'Mu2 Component', 'Mu2 Component delivers exceptional performance with a sleek design, making it indispensable for modern industry.', '690.47', 118818214),
  
  (1672789809, 'Nu2 Device', 'Nu2 Device offers cutting‐edge technology and innovative design, ensuring superior functionality and efficiency.', '368.40', 2090055520),
  
  (82064020, 'Xi2 Accessory', 'Xi2 Accessory features modern aesthetics and robust performance, designed to enhance productivity and operational efficiency.', '376.57', 1909159876),
  
  (334280806, 'Omicron Tool', 'Omicron Tool delivers exceptional performance and innovative features, engineered for high efficiency in demanding tasks.', '613.80', 370383848),
  
  (933304097, 'Pi2 Instrument', 'Pi2 Instrument offers advanced functionality and a compact design, ensuring optimal performance and ease of use.', '215.24', 1180269690),
  
  (1176553575, 'Rho2 Component', 'Rho2 Component is engineered for precision and durability, offering reliable performance and modern aesthetics for optimal results.', '19.95', 205207139),
  
  (194759979, 'Sigma2 Device', 'Sigma2 Device offers exceptional functionality and modern design, engineered for efficiency and durability in demanding settings.', '164.14', 2453412),
  
  (1199347202, 'Tau2 Gadget', 'Tau2 Gadget features innovative engineering and robust performance, designed to meet the demands of contemporary markets.', '196.99', 93921091),
  
  (1171111014, 'Upsilon2 Apparatus', 'Upsilon2 Apparatus delivers exceptional functionality and sleek design, engineered for high efficiency and reliability.', '765.48', 1693513734),
  
  (1572073439, 'W49 Instrument', 'W49 Instrument offers advanced functionality and robust performance, ensuring reliability and consistency in any environment.', '384.54', 453017185),
  
  (1411834737, 'X50 Device', 'X50 Device features cutting‐edge engineering and a sleek design, optimized for high performance and modern functionality.', '604.74', 1829201528),
  
  (736967162, 'Y51 Tool', 'Y51 Tool delivers reliable performance with a user‐friendly design, engineered to streamline operations and boost efficiency.', '816.87', 543817326),
  
  (1022993470, 'Z52 Module', 'Z52 Module integrates state‐of‐the‐art technology with robust construction, ensuring exceptional operational performance and durability.', '901.46', 2016889840);

