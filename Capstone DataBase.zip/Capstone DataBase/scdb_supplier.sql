-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: scdb
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `supplier`
--

DROP TABLE IF EXISTS `supplier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supplier` (
  `supplier_id` int NOT NULL,
  `name` varchar(50) NOT NULL,
  `address` varchar(100) DEFAULT NULL,
  `contact_person` varchar(50) DEFAULT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`supplier_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier`
--

LOCK TABLES `supplier` WRITE;
/*!40000 ALTER TABLE `supplier` DISABLE KEYS */;
INSERT INTO `supplier` VALUES (485,'Merwyn','8588 Forest Dale Plaza','Merwyn Andrei','657-185-7942'),(26904,'Lannie','1 International Point','Lannie Monaghan','491-417-4262'),(31588,'Terese','3109 West Court','Terese Shaw','482-837-6134'),(86213,'Ambur','70 Victoria Circle','Ambur Blackater','264-177-6456'),(86430,'Allison','9960 Hoard Crossing','Allison Cagan','955-278-4534'),(149777,'Nariko','4029 Merrick Street','Nariko Bukac','636-789-0301'),(162857,'Emmeline','88998 Columbus Avenue','Emmeline Liveley','307-143-5301'),(197732,'Analise','1954 Bashford Road','Analise Epilet','719-895-4509'),(203577,'Olly','6 Canary Center','Olly Darker','868-308-0043'),(260507,'Judye','3 West Park','Judye Jordi','971-770-3111'),(292185,'Lurlene','80860 Lakewood Circle','Lurlene Hannond','469-648-4007'),(296359,'Rebekkah','49 North Center','Rebekkah MacLucais','912-880-3798'),(301050,'Hyacintha','70109 Mallard Park','Hyacintha Targe','816-566-6074'),(316304,'Sigfrid','7368 Welch Alley','Sigfrid Haldane','473-431-6713'),(359021,'Anders','836 Mesta Terrace','Anders Halford','326-215-6615'),(374881,'Faye','22 Farwell Crossing','Faye Pevsner','818-905-1155'),(400963,'Bartholomeus','26 Forest Run Place','Bartholomeus Rochell','454-576-4927'),(420368,'Donaugh','5054 2nd Hill','Donaugh Fairpo','987-564-9460'),(448828,'Gloria','2 Maryland Junction','Gloria Sapp','149-114-0178'),(467572,'Bruno','1625 Westport Lane','Bruno Sheirlaw','772-484-5648'),(484902,'Cal','120 Caliangt Circle','Cal Swaffield','676-489-7403'),(522987,'Kenna','09 Pierstorff Trail','Kenna Windress','487-579-5142'),(536100,'Emlyn','3 Nelson Hill','Emlyn Poynton','778-397-7885'),(563252,'Eleni','5938 Warbler Point','Eleni Shave','836-966-1015'),(568299,'Lenette','66634 Charing Cross Place','Lenette Monsey','792-154-5269'),(580993,'Myrilla','61 Scoville Road','Myrilla Churms','547-778-5760'),(588719,'Sheelagh','30 Meadow Valley Street','Sheelagh Shewery','823-166-8424'),(609890,'Valene','5 Debs Parkway','Valene Feben','600-130-7933'),(610110,'Hildy','3 West Crossing','Hildy Lisciardelli','703-342-3862'),(612276,'Annice','69 Anzinger Park','Annice Autrie','775-760-1369'),(637537,'Ruthe','81 Acker Plaza','Ruthe Mohun','281-122-3676'),(643872,'Matthieu','2158 Schurz Hill','Matthieu Dunleavy','449-117-8300'),(649510,'Marquita','48672 Dovetail Place','Marquita Marchello','158-942-3371'),(664506,'Tess','34 Mallory Center','Tess McMeyler','969-282-8295'),(667982,'Steffen','7 Bellgrove Way','Steffen Duffell','668-197-0755'),(696993,'Milo','90 Express Parkway','Milo Duke','675-325-6635'),(704847,'Danica','94672 Saint Paul Pass','Danica Adamiec','236-215-5557'),(708977,'Noak','622 Nancy Avenue','Noak Vigus','561-887-1492'),(724156,'Nicolai','6 Waubesa Point','Nicolai Benedikt','930-945-7739'),(741413,'Betta','01 Orin Alley','Betta Flageul','699-306-0874'),(763623,'Flori','73431 Glacier Hill Hill','Flori Beesey','176-460-7796'),(807371,'Anissa','63110 Debs Place','Anissa Huegett','303-676-9670'),(818867,'Almeria','7 Holy Cross Road','Almeria Gather','894-926-2630'),(831201,'Neville','52330 Reindahl Place','Neville Darling','322-495-4337'),(881402,'Katharine','6 Barnett Park','Katharine Clowney','343-734-3460'),(900707,'Saxon','32 Messerschmidt Crossing','Saxon Nurden','437-421-3286'),(920330,'Waneta','91281 Nelson Center','Waneta Jime','903-359-6799'),(922926,'Anselm','7068 Emmet Alley','Anselm Lissaman','565-246-3256'),(940590,'Thornie','25875 Dennis Terrace','Thornie Myderscough','906-359-1408'),(949382,'Maureene','1 Del Mar Lane','Maureene Rawlcliffe','537-535-0362'),(953331,'Elise','75 Bay Street','Elise Thaller','264-520-5105'),(953403,'Ravid','952 Fairfield Crossing','Ravid Hearfield','217-368-7122'),(959925,'Bartel','32836 Florence Lane','Bartel Vye','437-683-4345'),(979075,'Becca','1 Westerfield Road','Becca Hatrick','501-733-3733'),(990265,'Valida','70 Tony Circle','Valida Durbridge','808-722-0501');
/*!40000 ALTER TABLE `supplier` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-17 16:40:56
